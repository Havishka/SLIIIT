	<div class=" slant-div">
        	<a class="bg-grey">COURSE CATEGORY</a>
		</div>
        <!--pannel-->
             <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingOne" style=" ">
                <div class="panel-title">
                    <a href="courses/auto_cad_2d_3D">
                        	AutoCAD 
                    </a>
                </div>
            </div>
          
        </div>
         <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading2" style=" ">
                <div class="panel-title">
                     <a href="courses/auto_cad_mep">
                        	AutoCAD MEP 
                    </a>
                </div>
            </div>
            <div id="collapse2" class="panel-collapse collapse bg-grey" role="tabpanel" aria-labelledby="heading2">
                <div class="panel-body">
                     <ul>
                     	<li>Diploma in CAD</li>
                        <li>Diploma in Draughting</li>
                        <li>AutoCAD MEP</li>
                        <li>DM CAD - Solid works</li>
                        <li>DM CADD - Pro/Engineer</li>
                        <li>DA CADD - Revit Architecture</li>
                        <li>DA  CADD - 3Ds Max</li>
                     </ul>
                    
                   
                      
                </div>
            </div>
        </div>
         <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading3" style=" ">
                <div class="panel-title">
                    <a href="courses/revit_architecture">
                        	Revit
                    </a>
                </div>
            </div>
            <div id="collapse3" class="panel-collapse collapse bg-grey" role="tabpanel" aria-labelledby="heading3">
                <div class="panel-body">
                     <ul>
                     	<li>Diploma in CAD</li>
                        <li>Diploma in Draughting</li>
                        <li>AutoCAD MEP</li>
                        <li>DM CAD - Solid works</li>
                        <li>DM CADD - Pro/Engineer</li>
                        <li>DA CADD - Revit Architecture</li>
                        <li>DA  CADD - 3Ds Max</li>
                     </ul>
                    
                   
                      
                </div>
            </div>
        </div>
         <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading4" style=" ">
                <div class="panel-title">
                    <a href="courses/revit_mep">
                        	Revit MEP 
                    </a>
                </div>
            </div>
            <div id="collapse4" class="panel-collapse collapse bg-grey" role="tabpanel" aria-labelledby="heading4">
                <div class="panel-body">
                     <ul>
                     	<li>Diploma in CAD</li>
                        <li>Diploma in Draughting</li>
                        <li>AutoCAD MEP</li>
                        <li>DM CAD - Solid works</li>
                        <li>DM CADD - Pro/Engineer</li>
                        <li>DA CADD - Revit Architecture</li>
                        <li>DA  CADD - 3Ds Max</li>
                     </ul>
                    
                   
                      
                </div>
            </div>
        </div>
         <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading5" style=" ">
                <div class="panel-title">
                    <a href="courses/auto_cad_civil_3d">
                        	Civil 3D
                    </a>
                </div>
            </div>
            <div id="collapse5" class="panel-collapse collapse bg-grey" role="tabpanel" aria-labelledby="heading5">
                <div class="panel-body">
                     <ul>
                     	<li>Diploma in CAD</li>
                        <li>Diploma in Draughting</li>
                        <li>AutoCAD MEP</li>
                        <li>DM CAD - Solid works</li>
                        <li>DM CADD - Pro/Engineer</li>
                        <li>DA CADD - Revit Architecture</li>
                        <li>DA  CADD - 3Ds Max</li>
                     </ul>
                    
                   
                      
                </div>
            </div>
        </div>
         <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading6" style=" ">
                <div class="panel-title">
                    <a href="courses/oracle_primavera">
                        	Primavera 
                    </a>
                </div>
            </div>
            <div id="collapse6" class="panel-collapse collapse bg-grey" role="tabpanel" aria-labelledby="heading6">
                <div class="panel-body">
                     <ul>
                     	<li>Diploma in CAD</li>
                        <li>Diploma in Draughting</li>
                        <li>AutoCAD MEP</li>
                        <li>DM CAD - Solid works</li>
                        <li>DM CADD - Pro/Engineer</li>
                        <li>DA CADD - Revit Architecture</li>
                        <li>DA  CADD - 3Ds Max</li>
                     </ul>
                    
                   
                      
                </div>
            </div>
        </div>
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading6" style=" ">
                <div class="panel-title">
                    <a href="courses/ptc_creo">
                        	PTC Creo 
                    </a>
                </div>
            </div>
           
        </div>
        
          
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading6" style=" ">
                <div class="panel-title">
                    <a href="courses/professional_in_project_planning_and_management">
                       Project Management 
                    </a>
                </div>
            </div>
           
        </div>
        
         <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading6" style=" ">
                <div class="panel-title">
                    <a href="courses/ms_project_concepts">
                      Microsoft Project
                    </a>
                </div>
            </div>
           
        </div>
        
       <!-- <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading6" style=" ">
                <div class="panel-title">
                    <a href="#">
                     3DS Max
                    </a>
                </div>
            </div>
           
        </div>
        
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading6" style=" ">
                <div class="panel-title">
                    <a href="#">
                     SolidWorks
                    </a>
                </div>
            </div>
           
        </div>
        
         <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="heading6" style=" ">
                <div class="panel-title">
                    <a href="#">
                     Staad PRO
                    </a>
                </div>
            </div>
           
        </div>-->

 

    
        
        
        
        
        

    </div>
        <!--panel/-->