<?php $this->load->view('include/header'); ?>
<!--container -->
<div class="container bg-white main-container ">
	<!--banner-->
	<div class="main-banner">
    	 <div id="Carousel" class="carousel slide carousel-fade ">
    
        <div class="carousel-inner">
        	<div class="item active">
              <div class="banner-caption">
            	<h1 class="text-uppercase">Industry
based
learning</h1>
                <h2>we teach students and professionals to make a positive impact in their career and prepare them for the better tomorrow.</h2>
                <button>Register Now              ></button>
            </div>
                    <img src="<?php echo base_url(); ?>images/banner/gallery.jpg" class="img-responsive"/>  
    		</div>
           
          
         </div>
           
        </div>
    
    </div>
    <!--banner /-->
    <!--left-->
    	<div class="col-md-9 left-content gallery-page">
        	<h2 class="red-heading">Gallery</h2>
     
        	<div class="col-md-12 no-pad">
            	
                
                <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/2.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                
                <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/3.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                 <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/4.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                 <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/5.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                 <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/6.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/7.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/8.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/9.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
                <div class="col-md-4">
                	<img class="img-responsive" src="<?php echo base_url(); ?>images/gallery/Photos/10.jpg" />
                    <h1 class="black-heading">Title</h1>
                </div>
            </div>
    
     	
            
        </div>
    <!--left/-->
    <!--right-->
    <?php
$this->load->view('include/panel_form');
?> 
    <!--right/-->
    <div class="clearfix"></div>
   
</div>
<!--container /-->
<?php
$this->load->view('include/footer');
?>    