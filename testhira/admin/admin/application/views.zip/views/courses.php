<?php $this->load->view('include/header'); ?>
<!--container -->
<div class="container bg-white main-container ">
	<!--banner-->
	<div class="main-banner">
    	 <div id="Carousel" class="carousel slide carousel-fade ">
    	<ol class="carousel-indicators" >
            <li data-target="#Carousel" data-slide-to="0" class="active"></li>
            <li data-target="#Carousel" data-slide-to="1"></li>
            <li data-target="#Carousel" data-slide-to="2"></li>
           
        </ol>
        <div class="carousel-inner">
        	<div class="item active">
               <div class="banner-caption">
            	<h1 class="text-uppercase">Professional
in Project
Planning and
Management</h1>
                <h2> Get the cadd centre  advantage. 
grow global.</h2>
                <button>Register Now ></button>
            </div>
                    <img src="<?php echo base_url(); ?>images/banner/courses/Planning_and_Management.jpg" class="img-responsive"/>  
    		</div>
            
            <div class="item ">
               <div class="banner-caption">
            	<h1 class="text-uppercase">Professional
in Project
Planning and
Management</h1>
                <h2> Get the cadd centre  advantage. 
grow global.</h2>
                <button>Register Now ></button>
            </div>
                    <img src="<?php echo base_url(); ?>images/banner/courses/oracle.jpg" class="img-responsive"/>  
    		</div>
            
            <div class="item ">
               <div class="banner-caption">
            	<h1 class="text-uppercase">2D + 3D Cad</h1>
                <h2> Learn the essential methors to make three dimensional models in different fields of engineering. Get the cadd centre  advantage. grow global.</h2>
                <button>Register Now ></button>
            </div>
                    <img src="<?php echo base_url(); ?>images/banner/courses/cad_2d_3d.jpg" class="img-responsive"/>  
    		</div>
           
          
         </div>
          
        </div>
    
    </div>
    <!--banner /-->
    <!--left-->
    	<div class="col-md-9 left-content">
        	<h2 class="red-heading">Courses</h2>
            <p class="para-text">We offer a unique design and interdisciplinary curriculum delivered through a industry based learning approach. With a vibrant learning centres and development programmes, we help our students to make a difference in the world. </p>
			
            
         <!--course page -->
         <div class="col-md-12 no-pad courses-main-div">
         	<div class="col-md-4 course-div">
           
       	    <a href="<?php echo base_url(); ?>cadd-lanka/course/auto-cad-2d-3D"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/AutoCad.png" class="img-responsive" alt=""/> </div>
             <p>AutoCAD</p>
            	</a>
            </div>
            <div class="col-md-4 course-div "><a href="<?php echo base_url(); ?>cadd-lanka/course/auto-cad-mep"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/AutoCad-Mep.png" class="img-responsive" alt=""/></div>
            	<p style="background:#f26522;">AutoCAD MEP</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/revit-architecture"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/Revit.png" class="img-responsive" alt=""/></div>
            	<p style="background:#39b54a;">Revit</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/revit-mep"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/Revit-MEP.png" class="img-responsive" alt=""/></div>
            	<p style="background:#00bff3;">Revit MEP</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/auto-cad-civil-3d"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/Civil-3D.png" class="img-responsive" alt=""/></div>
            	<p style="background:#0054a6;">Civil 3D</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/oracle-primavera"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/Primavera.png" class="img-responsive" alt=""/></div>
            	<p style="background:#101c63;">Primavera</p>
                </a>
            </div>
              <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/ptc-creo"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/GTO.png" class="img-responsive" alt=""/></div>
            	<p style="background:#603913;">PTC Creo</p>
                </a>
            </div>
             <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/professional-in-project-planning-and-management"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/Project-Management.png" class="img-responsive" alt=""/></div>
            	<p style="background:#101c63;">Project Management</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/ms-project-concepts"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/Microsoaft-Project.png" class="img-responsive" alt=""/></div>
            	<p style="background:#9e005d;">Microsoft Project</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="cadd-lanka/course/three-ds-max"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/3DS-MAX.png" class="img-responsive" alt=""/></div>
            	<p style="background:#f26522;">3DS MAX</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/solidworks"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/SolidWorks.png" class="img-responsive" alt=""/></div>
            	<p style="background:#ec008c;">SolidWorks</p>
                </a>
            </div>
            <div class="col-md-4 course-div"><a href="<?php echo base_url(); ?>cadd-lanka/course/staad-pro"><div class="course-div-img"><img src="<?php echo base_url(); ?>images/Staad-PRO.png" class="img-responsive" alt=""/></div>
            	<p style="background:#598527;">Staad PRO</p>
                </a>
            </div>
         </div>
         <!-- / course page-->
         <p>In addition, we provide all our graduates with the skills and knowledge required to get through that all-important interview.</p>
<p>Browse through our course pages to find out how you can earn a certificate in Cadd Centre. Need further assistance, <strong>send your details</strong> or contact us <strong>via phone</strong> or <strong>email</strong> to us to get back.</p>
            
        </div>
    <!--left/-->
     <?php
$this->load->view('include/panel_form');

?> 
    <!--right/-->
    <div class="clearfix"></div>
   
</div>
<!--container /-->
<?php
$this->load->view('include/footer');
?>    