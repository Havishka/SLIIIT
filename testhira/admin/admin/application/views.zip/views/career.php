<?php $this->load->view('include/header'); ?>
<!--container -->
<div class="container bg-white main-container ">
	<!--banner-->
	<div class="main-banner">
    	 <div id="Carousel" class="carousel slide carousel-fade ">
    
        <div class="carousel-inner">
        	<div class="item active">
             <div class="banner-caption">
            	<h1 class="text-uppercase">Find the
right course
for you</h1>
                <h2>Join and deepen your knowledge across engineering design and design thinking.</h2>
                <button>Register Now              ></button>
            </div>
             
                    <img src="<?php echo base_url(); ?>images/banner/how_to_join.jpg" class="img-responsive"/>  
    		</div>
           
          
         </div>
           
        </div>
    
    </div>
    <!--banner /-->
    <!--left-->
    	<div class="col-md-12 left-content news-page" id="joinForm">
        	<h2 class="red-heading">Job Portal – Registration form</h2>
     		 <form class="form-horizontal" role="form">
                <div class="form-group">
                   
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Register No :</label>
							 <input type="text" id="courseName" name="courseName" placeholder="Course Name" class="form-control" autofocus>
							 
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Full Name :</label>
							<input type="text" id="courseName" name="courseName" placeholder="Course Name" class="form-control">
							 
						</div>
					</div>
				 </div>
           
                   <div class="form-group col-md-12">
					<div class="col-md-6">
							 <label for="courseName" class="control-label">Address :</label><br>
							 <textarea class="form-control custom-control" style="margin: 0;"></textarea>
					</div>
					<div class="col-md-6" style="padding-left: 30px;">
							 <label for="courseName" class="control-label">Date of birth :</label>
							 <input type="date" id="birthDate" class="form-control">
							 
						</div>
				 </div>
                  
                    <div class="form-group">
                   
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Age :</label>
							 <input type="text" id="" class="form-control">
							 
						</div>
							<div class="col-md-6">
							 <label for="courseName" class="control-label">Gender :</label>
							 <input type="email" id="" class="form-control">
							 
						</div>
					</div>
				 </div>
                 
                   <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Phone No :</label>
							 <input type="tel" id="" class="form-control">
							 
						</div>
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Residence  :</label>
							 <input type="email" id="" class="form-control">
							 
						</div>
					</div>
				 </div>
                 
                  <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Mobile :</label>
							 <input type="tel" id="" class="form-control">
							 
						</div>
							<div class="col-md-6">
							 <label for="courseName" class="control-label">E mail :</label>
							 <input type="text" id="" class="form-control">
							 
						</div>
					</div>
				 </div>
              
               <div class="form-group col-md-12">
					<div class="col-md-12">
						
							 <label for="specialization" class="control-label">Courses completed with CADD centre :</label><br>
							
							 
						
							
								<div  class="col-md-3"><label for="courseName" class="control-label">Course 1 :</label>
							 <input type="text" id="" class="form-control"></div>
							 <div  class="col-md-3"><label for="courseName" class="control-label">Course 2 :</label>
							 <input type="text" id="" class="form-control"></div>
							 <div  class="col-md-3"><label for="courseName" class="control-label">Course 3 :</label>
							 <input type="text" id="" class="form-control"></div>
							 <div  class="col-md-3"><label for="courseName" class="control-label">Course 4 :</label>
							 <input type="text" id="" class="form-control"></div>
							 
							 
						
					</div>
				 </div>
              
               <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Interested Job Areas :</label>
							 							 <select id="specialization" name="specialization"  class="form-control" autofocus>
								 <option>Civil</option>
								  <option>Mechanical</option>
								   <option>Architectural</option>
								    <option>Interior Design</option>
							</select>
							 
						</div>
							<div class="col-md-6">
							 <label for="courseName" class="control-label">Locations :</label>
							 <select id="specialization" name="specialization"  class="form-control" autofocus>
								 <option>Foreign</option>
								  <option>Local</option>
								   <option>Architectural</option>
								    <option>Interior Design</option>
							</select>
							 
							 
						</div>
					</div>
				 </div>
             
             <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Category :</label>
							 <select id="specialization" name="specialization"  class="form-control" autofocus>
								 <option>Full time</option>
								  <option>Part time</option>
								 
							</select>
							 
						</div>
							<div class="col-md-6">
							 <label for="courseName" class="control-label">Upload Your CV :</label>
							 <input type="file" id="" class="form-control">
							 
							 
						</div>
					</div>
				 </div>
              
               
                 
                 
                    <div class="form-group">
					<div class="col-md-2">
						
					
							  <button type="submit" class="btn btn-primary btn-block">Register</button>
							
					</div>
				 </div>
                  
                  
                  
                  
                  
                   
                  
            
            </form> 
        
    		
     	
            
        </div>
    <!--left/-->
    <!--right-->
    <?php
//$this->load->view('include/panel_form');
?> 
    <!--right/-->
    <div class="clearfix"></div>
   
</div>
<!--container /-->
<?php
$this->load->view('include/footer');
?>    