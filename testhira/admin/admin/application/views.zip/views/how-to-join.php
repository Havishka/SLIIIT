<?php $this->load->view('include/header'); ?>
<!--container -->
<div class="container bg-white main-container ">
	<!--banner-->
	<div class="main-banner">
    	 <div id="Carousel" class="carousel slide carousel-fade ">
    
        <div class="carousel-inner">
        	<div class="item active">
             <div class="banner-caption">
            	<h1 class="text-uppercase">Find the
right course
for you</h1>
                <h2>Join and deepen your knowledge across engineering design and design thinking.</h2>
                <button>Register Now              ></button>
            </div>
             
                    <img src="<?php echo base_url(); ?>images/banner/how_to_join.jpg" class="img-responsive"/>  
    		</div>
           
          
         </div>
           
        </div>
    
    </div>
    <!--banner /-->
    <!--left-->
    	<div class="col-md-12 left-content news-page" id="joinForm">
        	<h2 class="red-heading">How to Join CADDLanka</h2>
     		 <form class="form-horizontal" role="form">
                <div class="form-group">
                   
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Course Name :</label>
							 <input type="text" id="courseName" name="courseName" placeholder="Course Name" class="form-control" autofocus>
							 
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Course Specialization :</label>
							 <select id="specialization" name="specialization"  class="form-control" autofocus>
								 <option></option>
							</select>
							 
						</div>
					</div>
				 </div>
                
              <div class="form-group">	
                  <div class="col-md-12">
						<div class="col-md-6">
							 <label for="fullName" class="control-label">Full Name :</label><br>
							 
							<div class="col-md-3 no-pad"><select id="specialization" name="specialization"  class="form-control" autofocus>
								 <option></option>
							</select></div>
							<div class="col-md-9"><input type="text" id="fullName" name="fullName" placeholder="Course Name" class="form-control" autofocus></div>
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Course Specialization :</label>
							 <select id="specialization" name="specialization"  class="form-control" autofocus>
								 <option></option>
							</select>
							 
						</div>
					</div>
				 </div>
                   <div class="form-group col-md-12">
					<div class="col-md-12">
							 <label for="courseName" class="control-label">Home Address :</label><br>
							 <textarea class="form-control custom-control"></textarea>
					</div>
				 </div>
                  
                    <div class="form-group">
                   
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Date of birth :</label>
							 <input type="date" id="birthDate" class="form-control">
							 
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">National ID / PP No :</label>
							 <input type="text" id="" class="form-control">
							 
						</div>
					</div>
				 </div>
                 
                   <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Email address :</label>
							 <input type="email" id="" class="form-control">
							 
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Phone(Mobile & Res) :</label>
							 <input type="tel" id="" class="form-control">
							 
						</div>
					</div>
				 </div>
                 
                  <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Occupation :</label>
							 <input type="email" id="" class="form-control">
							 
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Company/ University/ Institute name :</label>
							 <input type="tel" id="" class="form-control">
							 
						</div>
					</div>
				 </div>
                 
                  <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Company/ University/ Institute address :</label>
							 <input type="text" id="" class="form-control">
							 
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Company/ University/ Phone no(office) :</label>
							 <input type="text" id="" class="form-control">
							 
						</div>
					</div>
				 </div>
                  <div class="form-group">
					<div class="col-md-12">
						<div class="col-md-6">
							 <label for="courseName" class="control-label">Company/ University/  Phone no(mobile) :</label>
							 <input type="email" id="" class="form-control">
							 
						</div>
						<div class="col-md-6">
							 <label for="specialization" class="control-label">Please select :</label>
							 <select id="specialization" name="specialization"  class="form-control" autofocus>
								 <option></option>
							</select>
							 
						</div>
					</div>
				 </div>
                  <div class="form-group">
					<div class="col-md-12">
							 <label for="specialization" class="control-label">How did you here about the CADD CENTER Lanka:</label><br>
						<div class="col-md-4">
							<div class="checkbox">
                            <label>
                                <input type="checkbox" id="calorieCheckbox" value="">News Paper Advertisement
                            </label>
                        </div>
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" id="calorieCheckbox" value="">Web Site 
                            </label>
                        </div>
                      
                      
						</div>
						 <div class="col-md-4">
						 	  <div class="checkbox">
                            <label>
                                <input type="checkbox" id="calorieCheckbox" value="">News Letter
                            </label>
							</div>
							 <div class="checkbox">
								<label>
									<input type="checkbox" id="calorieCheckbox" value="">From a Friend
								</label>
							</div>
						 </div>
						  <div class="col-md-4">
						 	  <div class="checkbox">
                            <label>
                                <input type="checkbox" id="calorieCheckbox" value="">Exhibition
                            </label>
							</div>
							 <div class="checkbox">
								<label>
									<input type="checkbox" id="calorieCheckbox" value="">E-Mail Advertisement
								</label>
							</div>
						 </div>
							 <label for="specialization" class="control-label">Others Please Specify:</label><br>
							  <input type="text" id="" class="form-control">
					
					</div>
				 </div>
                 
                 
                    <div class="form-group">
					<div class="col-md-2">
						
					
							  <button type="submit" class="btn btn-primary btn-block">Register</button>
							
					</div>
				 </div>
                  
                  
                  
                  
                  
                   
                  
            
            </form> 
        
    		
     	
            
        </div>
    <!--left/-->
    <!--right-->
    <?php
//$this->load->view('include/panel_form');
?> 
    <!--right/-->
    <div class="clearfix"></div>
   
</div>
<!--container /-->
<?php
$this->load->view('include/footer');
?>    