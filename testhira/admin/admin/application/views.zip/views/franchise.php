<?php $this->load->view('include/header'); ?>
<!--container -->
<div class="container bg-white main-container ">
	<!--banner-->
	<div class="main-banner">
    	 <div id="Carousel" class="carousel slide carousel-fade ">
    
        <div class="carousel-inner">
        	<div class="item active">
              <div class="banner-caption">
            	<h1 class="text-uppercase">Welcome to 
Cadd Centre
Sri Lanka</h1>
                <h2>Browse our franchise details for unit and franchise opportunities in 
Sri Lanka. Join with us and grow with the World-Class Cadd Education.</h2>
                <button>Register Now              ></button>
            </div>
                    <img src="<?php echo base_url(); ?>images/banner/franchise.jpg" class="img-responsive"/>  
    		</div>
           
          
         </div>
           
        </div>
    
    </div>
    <!--banner /-->
    <!--left-->
    	<div class="col-md-9 left-content news-page">
        	<h2 class="red-heading">Franchise</h2>
     
        	<h3 >Design and Technology Training plays a critical role for the world’s economic development. </h3>
            <p>Investments in Training technology and education are the fundamental infrastructure help in building the same.

Having said strong market potential for good quality technology training, CADD Center Srilanka now invites training partners all over Srilanka.</p>
<p>The features of the partnership can be spoken in five points mentioned below:</p>
<ul>
	<li>Mutually benefiting model</li>
    <li>Powerful System</li>
    <li>Highly Profitable</li>
    <li>Transparent</li>
    <li>Functional Support</li>
</ul>






<p>Grow with us.  Become a training partner today!</p> 

<h3 class="blue-heading">Our Franchise Locations:</h3>
<p>Franchise locations list given below.</p>

<div class="col-md-12">
	<div class="col-md-6">
    	<address>
        	<strong>Gampaha</strong><br>
	IDA Training Centre <br>
Address : No.6/19,May Field 2,Sapugasthanna Road,Kalagedihena<br>
<i class="fa fa-phone"></i>  071668 5899/ 0773 168 968<br>
<i class="fa fa-envelope"></i> nevilranaa@gmail.com,<br>
 
        </address>
    </div>
    
    <div class="col-md-6">
    	<address>
        	<strong>Batticaloa </strong><br>
Blue Sky Campus<br>
23A, 1st Cross, Gnanasooriyam Sq, Trinco Road<br>
Batticaloa<br>
 <i class="fa fa-phone"></i> 0776154813/0652227062<br>
<i class="fa fa-envelope"></i> info@blueskycampus.com<br>

        </address>
    </div>
    <div class="clearfix"></div>
    
    <div class="col-md-6">
    	<address>
        	<strong>Bandarawela</strong><br>
IDM Bandarawela <br>
No 232 2/1 <br>
Badulla road<br>
Bandarawela<br>
<i class="fa fa-phone"></i> 071 63 42 611<br>
<i class="fa fa-envelope"></i> osadauk@gmail.com, 

 
        </address>
    </div>
    
    
    <div class="col-md-6">
    	<address>
        	<strong>Kurunagala </strong>
No.18, 1st Floor,<br>
Jayawansa Building,<br>
Mihindu Mawatha,<br>
Kurunegala.<br>
<i class="fa fa-phone"></i> +94 37 222 14 00<br>
<i class="fa fa-emvelope"></i> +94 37 737 73 87

        </address>
    </div>
      <div class="clearfix"></div>
    
    <div class="col-md-6">
    	<address>
        	<strong>Anuradapura</strong><br>
E3 Acadamy,<br> 
No:521 <br>
7th Cross Street,<br>
New Town <br>
Anuradapura<br>
<i class="fa fa-phone"></i> 025 5 110 110 <br>
 <i class="fa fa-envelope"></i> e3anuradhapura@gmail.com<br>


 
        </address>
    </div>
    
     
    <div class="col-md-6">
    	<address>
        	<strong>Polonnaruwa</strong>
E3 Acadamy,<br> 
No:521 <br>
7th Cross Street,<br>
New Town <br>
Anuradapura<br>
<i class="fa fa-phone"></i> 025 5 110 110 <br>
 <i class="fa fa-envelope"></i> e3anuradhapura@gmail.com<br>


 
        </address>
    </div>
    
     <div class="clearfix"></div>
    <div class="col-md-6">
    	<address>
       <strong> Galle.</strong>
ETS Galle Branch, <br>
Chamber of Commerce Building,<br>
Sri Gnanobasha Mawatha,<br>
Galle.<br>
 <i class="fa fa-phone"></i>0766 260850 /091 5 110 110<br>
<i class="fa fa-envelope"></i>dilan@ets.lk<br>


 
        </address>
    </div>
    
      
    <div class="col-md-6">
    	<address>
       <strong> Kegalle.</strong>
ETS Training Centre, <br>
No 314,<br>
Kandy Road,<br>
Kegalle.<br>
 <i class="fa fa-phone"></i> 035 5 110 110 <br>
 <i class="fa fa-envelope"></i> kegalle@ets.lk



 
        </address>
    </div>
    
</div>
    
     	
            
        </div>
    <!--left/-->
    <!--right-->
    <?php
$this->load->view('include/panel_form');
?> 
    <!--right/-->
    <div class="clearfix"></div>
   
</div>
<!--container /-->
<?php
$this->load->view('include/footer');
?>    