<div class="other-courses">
	<ul>
    	<li><a href="">Manual Drafting</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/auto-cad-2d-3D">Auto CAD 2D + 3D</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/revit-architecture">Revit Architecture</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/three-ds-max">3ds MAX</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/sap-2000">SAP 2000</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/staad-pro">STAAD.Pro</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/etabs">Etabs</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/auto-cad-civil-3d">AutoCAD Civil 3d</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/solidworks">Solidworks</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/ptc-creo">PTC Creo</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/revit-mep">Revit MEP</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/basic-quantity-surveying">Basic Quantity Surveying </a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/mep-qs">MEP QS</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/autodesk-navisworks">Autodesk Navisworks</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/autoCAD-electrical">AutoCAD Electrical</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/oracle-primavera">Oracle Primavera</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/ms-project-concepts">MS Project + Concepts</a></li>
        <li><a href="<?php echo base_url(); ?>cadd-lanka/course/professional-in-project-planning-and-management">Professional in Project Planning and Management</a></li>
    </ul>
</div>