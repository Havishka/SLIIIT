<?php $this->load->view('include/header'); ?>
<!--container -->	
<div class="container bg-white main-container ">
	<!--banner-->
		<div class="main-banner">
    	 <div id="Carousel" class="carousel slide carousel-fade ">
    	  <div class="carousel-inner">
        	<div class="item active">
               <div class="banner-caption">
            	<h1 class="text-uppercase">Courses 
To build ta 
better world 
through 
engineering
and design</h1>
                <!--<h2>Over 11 years of professional career development experience as an institute and conducts accredited courses of world renown software giants around the world.</h2>-->
                <button>Register Now              ></button>
            </div>
                    <img src="<?php echo base_url(); ?>images/banner/course.jpg" class="img-responsive"/>  
    		</div>
           
          
         </div>
           
        </div>
    
    </div>
    <!--banner /-->
    <!--left-->
    	<div class="col-md-9 left-content aboutus-page">
        	<h2 class="red-heading">About MS Project + Concepts (Certificate in Project Planning and Management) Course  </h2>
            <h3 class="black-heading">Microsoft project is a project management software program that is developed and sold by Microsoft and also designed specially to assist project manager for development of a plan, putting resources to tasks, tracking their progress, and ascertaining workloads.</h3>
            <p class="para-text">Sharpen your end-to-end project management skill by mastering on the best project management tool. </p>
            
        <hr>
        <h4 class="blue-heading">Objectives </h4>
        <ul>
        <li>It will teach you ways to customize projects by using templates, configuring own objects and spreading information across the organization.</li>
<li>It also aims to teach project managers ways to leverage Microsoft project and optimize resources on complex projects. </li>
<li>Provides skills of creating cross-project links and track status across multiple projects. </li>
</ul>

      
         <hr>
        <h4 class="blue-heading">Who Should be Aiming for the Course?   </h4>
        <ul>
        	<li>Project managers, delivery managers and senior managers working on complex and multiple projects.  </li>
<li>Operations managers, consultants, and tech professionals who are in organizations that use the standalone version of Microsoft Project.</li> 
<li>Management and engineering graduates. </li>

 
        </ul>
         <hr>
         <h4 class="blue-heading">What’s in it for me?  </h4>
         <p>Individuals who complete the course will be able to avail the following benefits: </p>
            <ul>
            	<li>Project managers will learn to get the best out of the people and projects that they oversee.</li> 
<li>Professionals will learn techniques of delivering project on-time and within scope & budget.</li>
<li>This certification will improve your career by successfully managing projects.</li>
<li>It will distinguish you from your colleagues and ensure you to get recognized in your organization. </li>
            </ul>
            <hr>
         <h4 class="blue-heading">Course Highlights  </h4>
            <ul>
          <li>High Definition demo’s on Microsoft Project tools.</li>
<li>50 hours of high-quality learning content.</li>
<li>10 sessions</li>
<li>Learn practical project applications based on business situations. </li>
            </ul>
            
            <hr>
        <h4 class="blue-heading">Pre-Requisite  </h4>
        <p>Although the course is geared for project managers, but those who have cleared A/L will be benefited from the program.</p>
        
          <hr>
        <h4 class="blue-heading">Curriculum </h4>
        <p>The course curriculum is carefully designed to meet the industry standards and market requirements. The major areas covered under this certification are:</p>s
                <ul>
        	<li>Set Project Working Time (Calendars)  </li>
<li>Define Activities, Sequence & Estimate Durations  </li>
<li>Develop a Schedule Plan  </li>
<li>CPM (Critical Path Method) </li>
<li>PERT- Program Evaluation Review Technique, PDM - Precedence Diagramming Method  </li>
<li>Resource Planning & Cost Estimation and Risk Identification</li>
<li>Preparing Resources, Allocation of Material & Work Resources, Resource Work Contours & Resources Leveling</li>
<li>Methods of developing different types of reports according to the Industrial Needs </li>
<li>Scheduling Multiple Projects </li>
<li>Project Management Concepts</li>


      </ul>
     
            
        </div>
    <!--left/-->
    <!--right-->
    <?php
$this->load->view('include/right_panel_form');

?> 
    <!--right/-->
    <div class="clearfix"></div>
   
</div>
<!--container /-->
<?php
$this->load->view('include/footer');
?>    